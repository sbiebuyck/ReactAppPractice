// id values will be unique
const items = [
    { id: '0a3451', name: 'Milk', price: 2.55 },
    { id: '0a3672', name: 'Pizza', price: 8.99 },
    { id: '0a3459', name: 'Mango', price: 4.00 },
	{ id: '1a3451', name: 'Strawberries', price: 17.99 },
	{ id: '2a3451', name: 'Yogurt', price: 8.95 },
	{ id: '0a3459', name: 'Red Raspberries', price: 12.44 },
	{ id: '3a3451', name: 'Sesame Seed Bagels', price: 8.95 },
	{ id: '4a3451', name: 'Organic Yogurt Tubes', price: 12.00 },
	{ id: '5a3451', name: 'Pears', price: 3.22 },
	{ id: '6a3451', name: 'Pasta Salad', price: 5.23 },
	{ id: '7a3451', name: 'Eggs 1 dozen', price: 3.59 },
];

export default items;